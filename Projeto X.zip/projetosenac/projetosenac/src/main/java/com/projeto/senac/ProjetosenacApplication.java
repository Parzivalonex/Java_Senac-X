package com.projeto.senac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetosenacApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetosenacApplication.class, args);
	}

}
