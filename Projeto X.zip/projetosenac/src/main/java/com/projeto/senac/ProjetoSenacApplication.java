package com.projeto.senac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@EntityScan(basePackages ="com.projeto.senac.model" )
@ComponentScan(basePackages = "com.projeto.senac.*")//aqui ele irá pegar todo as informações;
@SpringBootApplication
public class ProjetoSenacApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoSenacApplication.class, args);
	}

}
