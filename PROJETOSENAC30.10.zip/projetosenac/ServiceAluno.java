package com.projeto.senac.service;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.projeto.senac.model.Aluno;
import com.projeto.senac.repository.AlunoRepository;

@Service
public class ServiceAluno {

	@Autowired
	private AlunoRepository alunoRepository;
	
	public String gerarMatricula(int id) {
		Date data= new Date();
		Calendar cal= Calendar.getInstance();
		cal.setTime(data);
		int ano = cal.get(Calendar.YEAR);
		String txt= "SENAC";
		return (txt + ano + (id+1)); // SENAC2023
	}
	
	
	public String cadastrarAluno(Aluno aluno) {
		
		Aluno alunoExistente= alunoRepository.findByCpf(aluno.getCpf());
		if(alunoExistente == null) {
			Aluno aux = alunoRepository.findLastInsertedAluno();
		}
		return null;
	}
}
