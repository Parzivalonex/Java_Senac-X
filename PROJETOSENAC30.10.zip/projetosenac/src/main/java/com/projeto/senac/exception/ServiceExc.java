package com.projeto.senac.exception;

public class ServiceExc extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ServiceExc(String msg){
		super(msg);
	}

}
