package com.projeto.senac.exception;

public class ServiceExc extends Exception {
	private static final long serialVersionUID = 1L;

	public ServiceExc(String msg) {

		super(msg);

	}

}
